export type Strength = "Tugev" | "Kaudne" | "Suunav" | "Vaidlustatud" | "Keskmine";

export type Part = {
  name: string;
  group: "USKUMUSED" | "TEGEVUSED";
  meaning: string;
  strength: Strength;
  sources: string;
};

export const parts: Part[] = [
  { name: "Inimene", group: "USKUMUSED", meaning: "Inimene on võimeline enamaks kui hetkel välja paistab", strength: "Tugev", sources: "Dweck (2006); Heslin, VandeWalle & Latham (2006)" },
  { name: "Suhe", group: "USKUMUSED", meaning: "Töötaja usaldus juhi vastu on coachiva juhtimise eeldus", strength: "Kaudne", sources: "Gregory & Levy (2010); Edmondson (1999)" },
  { name: "Autonoomia", group: "USKUMUSED", meaning: "Inimene suudab end ise juhtida, kui tal on suurem kontroll oma valikute üle", strength: "Suunav", sources: "Deci & Ryan (2000); Gagné & Deci (2005)" },
  { name: "Juhendamine", group: "TEGEVUSED", meaning: "Ootuste kokkuleppimine, tagasiside korraldamine, kokkulepete kontroll", strength: "Tugev", sources: "Ellinger et al. (2003); Locke & Latham (2002)" },
  { name: "Võimestamine", group: "TEGEVUSED", meaning: "Küsimine, kuulamine, otsus jääb inimesele", strength: "Vaidlustatud", sources: "Cheong et al. (2019); Lee et al. (2018)" },
  { name: "Inspireerimine", group: "TEGEVUSED", meaning: "Arengu potentsiaali välja ütlemine, väljakutsete esitamine", strength: "Keskmine", sources: "Bass & Riggio (2006); Eden (1990)" },
];

/** Visual weight of the evidence label, 1–4 filled segments. */
export const strengthLevel: Record<Strength, number> = {
  Tugev: 4,
  Keskmine: 3,
  Suunav: 2,
  Kaudne: 2,
  Vaidlustatud: 1,
};

export const freqLabels = [
  "mitte kordagi",
  "korra",
  "paar korda",
  "umbes kord nädalas",
  "mitu korda nädalas",
  "peaaegu iga päev",
];

// PLACEHOLDER statements except the first of each screen (approved examples).
export const screen1 = {
  prompt: "Viimase nelja nädala jooksul, kui sageli sa…",
  items: [
    "ütlesid kellelegi selgelt, millist tulemust sa temalt ootad",
    "andsid kellelegi tagasisidet tema konkreetse tegevuse kohta",
    "tulid tagasi varem tehtud kokkuleppe juurde",
    "küsisid inimeselt, mida tema ise teeks, enne kui oma lahenduse pakkusid",
    "kuulasid lõpuni, ilma et oleksid vahele seganud",
    "jätsid otsuse inimesele, kuigi oleksid ise teisiti teinud",
    "ütlesid kellelegi välja, milles ta on arenenud",
    "andsid kellelegi ülesande, mis oli talle päris väljakutse",
    "rääkisid kellegagi tema järgmisest arenguhüppest",
  ],
};

export const screen2 = {
  prompt: "Kui hästi kirjeldab see sinu tegelikke valikuid viimase poole aasta jooksul?",
  items: [
    "Kui inimene ei tule ülesandega toime, uurin kõigepealt, mida ta peaks selleks õppima.",
    "Annan raskeid ülesandeid ka neile, kes pole end veel tõestanud.",
    "Panustan aega, et inimesed julgeksid mulle oma vigadest rääkida.",
    "Hoian oma lubadusi ka siis, kui see on ebamugav.",
    "Räägin avameelselt, ka siis, kui uudis on halb.",
    "Jätan inimesele võimaluse teha asi omal moel.",
    "Ei kontrolli vahetulemusi sagedamini, kui kokku leppisime.",
    "Lasen inimesel ise otsustada, kuidas ta eesmärgini jõuab.",
    "Usaldan meeskonda ka siis, kui mind kohal pole.",
  ],
};

export const programme = {
  title: "Coachiva juhi võimekuste sprint",
  body: "Iga tööpäeva lõpus saad coachiva juhi võtmetegevustele tähelepanu juhtimiseks kirja kuue jah/ei küsimusega. Vastamine võtab alla minuti. Kolme nädala pärast näed, kui sageli need tegevused sinu päeva tegelikult jõudsid.",
  price: "15 € koos käibemaksuga",
};

export const fmt = (n: number) => n.toFixed(1).replace(".", ",");
