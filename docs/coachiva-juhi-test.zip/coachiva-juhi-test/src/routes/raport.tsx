import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/site";
import { ResultRow, sampleActions, sampleBeliefs } from "@/components/report";
import { programme } from "@/lib/content";
import { ContactOptIn } from "@/components/contact-opt-in";

export const Route = createFileRoute("/raport")({
  head: () => ({
    meta: [
      { title: "Sinu raport — Coachiva juhi test" },
      { name: "description", content: "Sinu coachiv juhtimine praegu: kolm tegevust ja kolm uskumust." },
      { property: "og:title", content: "Sinu coachiv juhtimine praegu" },
      { property: "og:description", content: "Isiklik raport coachiva juhi testist." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Report,
});

const pairs = [
  { head: "Inimene · Inspireerimine", text: "Usud kindlalt, et inimesed arenevad, kuid ütled seda neile harva välja. Siin on sinu kõige lühem tee." },
  { head: "Suhe · Juhendamine", text: "Selged ootused ja kokkulepete juurde tagasi tulemine toetavad usaldust, mida sa niigi hoiad." },
  { head: "Autonoomia · Võimestamine", text: "Küsid ja kuulad, kuid otsus jääb sageli sinu kätte. Uskumus ja tegevus liiguvad koos." },
];

function Report() {
  return (
    <Page>
      <section className="border-b-2 border-rule">
        <div className="mx-auto max-w-3xl px-5 pb-12 pt-14 md:pt-20 rise">
          <p className="eyebrow mb-6 text-muted-foreground">Raport · oktoober 2026</p>
          <h1 className="text-7xl md:text-9xl">Sinu coachiv juhtimine <span className="marker">praegu</span></h1>
          <p className="mt-8 text-lg leading-relaxed">
            See raport näitab, kui sageli kolm coachiva juhi tegevust viimase nelja nädala jooksul sinu päeva jõudsid ja milliseid valikuid sa juhina teed. Iga tegevus ja uskumus on eraldi, sest need on erinevad asjad.
          </p>
        </div>
      </section>

      {[{ label: "TEGEVUSED", sub: "kui sageli viimase nelja nädala jooksul", items: sampleActions }, { label: "USKUMUSED", sub: "mida sinu valikud näitavad", items: sampleBeliefs }].map((g) => (
        <section key={g.label} className="border-b-2 border-rule">
          <div className="mx-auto max-w-3xl px-5 py-12">
            <div className="mb-2 flex items-baseline justify-between border-b-4 border-rule pb-3">
              <span className="eyebrow">{g.label}</span>
              <span className="text-sm text-muted-foreground">{g.sub}</span>
            </div>
            {g.items.map((r) => <ResultRow key={r.name} r={r} />)}
          </div>
        </section>
      ))}

      <section className="grain border-b-2 border-rule bg-bone">
        <div className="mx-auto max-w-5xl px-5 py-16">
          <h2 className="mb-8 text-5xl md:text-6xl">Uskumus ja tegevus koos</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {pairs.map((p) => (
              <div key={p.head} className="border-2 border-rule bg-background p-5">
                <p className="eyebrow border-b-2 border-rule pb-3">{p.head}</p>
                <p className="mt-4">{p.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-b-2 border-rule">
        <div className="mx-auto max-w-3xl px-5 py-16 md:py-20">
          <h2 className="mb-8 text-5xl md:text-6xl">Mida sinu tulemused koos näitavad</h2>
          <div className="border-l-4 border-signal pl-6">
            <p className="text-xl italic leading-relaxed md:text-2xl md:leading-relaxed">
              Sinu tugevus on selgus: inimesed teavad, mida sa neilt ootad, ja sa tuled kokkulepete juurde tagasi. See on vundament, millele paljud juhid alles ehitavad. Samas jääb arengu välja ütlemine sinu päevas haruldaseks, kuigi su valikud näitavad, et sa usud inimeste arengusse kindlalt. See vahe on hea koht alustamiseks, sest see ei nõua uut uskumust, vaid ühte lauset nädalas. Küsimine on sul olemas; järgmine samm on jätta otsus kauemaks inimese kätte.
            </p>
            <p className="mt-6 text-sm text-muted-foreground">— kirjutatud sinu vastuste põhjal</p>
          </div>
        </div>
      </section>

      <section className="border-b-2 border-rule">
        <div className="mx-auto max-w-3xl px-5 py-12">
          <div className="bg-bone p-6 text-muted-foreground">
            <p className="eyebrow mb-3 text-foreground">Mida see ei tähenda</p>
            <p>See ei ole hinne ega võrdlus teiste juhtidega. Tulemus näitab, kui sageli tegevused sinu päeva jõudsid ja milliseid valikuid sa teed — mitte seda, kui hästi sa neid teed. Seda näevad kõige paremini sinu inimesed.</p>
          </div>
        </div>
      </section>

      <section className="bg-signal">
        <div className="mx-auto max-w-3xl px-5 py-16 md:py-20">
          <h2 className="text-6xl md:text-8xl">{programme.title}</h2>
          <p className="mt-6 text-lg leading-relaxed">{programme.body}</p>
          <p className="display mt-6 text-4xl">{programme.price}</p>
          <button className="mt-8 w-full border-2 border-rule bg-ink py-5 text-lg font-semibold text-background shadow-[5px_5px_0_0_var(--background)] md:w-auto md:px-12">
            Alusta · 15 €
          </button>
          <p className="mt-4 text-sm">Sul on ettevõttelt kood? Sisesta see makselehel.</p>
          <ContactOptIn />
        </div>
      </section>
    </Page>
  );
}
