import { createFileRoute, Link } from "@tanstack/react-router";
import { Page } from "@/components/site";
import { ResultRow, sampleActions } from "@/components/report";
import { parts, programme } from "@/lib/content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Coachiva juhi test — kus sa coachiva juhina praegu oled" },
      { name: "description", content: "18 väidet, viis minutit. Tasuta raport kolmest tegevusest ja kolmest uskumusest, kohe ekraanile ja e-postile." },
      { property: "og:title", content: "Coachiva juhi test" },
      { property: "og:description", content: "Viie minutiga teada, kus sina praegu coachiva juhina oled. Tasuta." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function StartButton({ big = false }: { big?: boolean }) {
  return (
    <Link
      to="/test"
      className={`group inline-flex items-center gap-4 border-2 border-rule bg-signal font-semibold shadow-[5px_5px_0_0_var(--rule)] transition-all hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[3px_3px_0_0_var(--rule)] ${big ? "px-7 py-5 text-lg" : "px-6 py-4"}`}
    >
      Alusta testi · 5 min
      <span className="transition-transform group-hover:translate-x-1" aria-hidden>→</span>
    </Link>
  );
}

function Index() {
  const beliefs = parts.filter((p) => p.group === "USKUMUSED");
  const actions = parts.filter((p) => p.group === "TEGEVUSED");

  return (
    <Page>
      {/* Hero */}
      <section className="relative overflow-hidden border-b-2 border-rule">
        <div className="grain absolute inset-y-0 right-0 hidden w-1/3 border-l-2 border-rule bg-bone md:block" aria-hidden />
        <div className="relative mx-auto grid max-w-6xl gap-10 px-5 pb-14 pt-12 md:grid-cols-[1.4fr_1fr] md:pb-24 md:pt-20">
          <div className="rise">
            <p className="eyebrow mb-6 text-muted-foreground">Enesehinnang juhile · 18 väidet</p>
            <h1 className="text-[22vw] leading-[0.82] md:text-[10.5rem]">
              Coachiva<br />juhi <span className="marker">test</span>
            </h1>
            <p className="mt-8 max-w-lg text-lg leading-relaxed md:text-xl">
              Coachiv juhtimine on kombinatsioon uskumustest ja tegevustest. Testi tehes saad viie minutiga teada, kui coachiv sa praegu juhina oled.
            </p>
            <div className="mt-9"><StartButton big /></div>
            <p className="mt-5 text-sm text-muted-foreground">Tasuta. Raport kohe ekraanile ja e-postile.</p>
          </div>
          <div className="relative self-end rise [animation-delay:200ms]">
            <div className="border-2 border-rule bg-background p-5 shadow-[8px_8px_0_0_var(--rule)] md:rotate-[1.5deg]">
              <div className="flex items-center justify-between border-b-2 border-rule pb-3">
                <span className="eyebrow">Sinu raport</span>
                <span className="h-3 w-3 bg-signal ring-2 ring-rule" />
              </div>
              <ResultRow r={sampleActions[0]!} compact />
            </div>
          </div>
        </div>
      </section>

      {/* Tension */}
      <section className="bg-ink text-background">
        <div className="mx-auto max-w-4xl px-5 py-20 md:py-28">
          <p className="text-2xl leading-snug md:text-4xl md:leading-tight">
            Coachiv juhtimine on ühelt poolt ülipopulaarne ja teiselt poolt erakordselt ebamäärane nähtus. Sellest räägitakse koolitustel, Linkedinis, juhtimispõhimõtetes. Ja tegelikult pole olemas ühte konkreetset definitsiooni, mis see täpselt on.
          </p>
          <div className="mt-12 grid gap-px border-2 border-background/30 bg-background/30 md:grid-cols-3">
            {["Kas see on vahend või filosoofia?", "Igas olukorras rakendatav või pigem täppistöövahend?", "Pehmodele või hoopis tugevatele juhtidele?"].map((q) => (
              <p key={q} className="display bg-ink p-6 text-3xl leading-none text-signal">{q}</p>
            ))}
          </div>
        </div>
      </section>

      {/* Model */}
      <section className="border-b-2 border-rule">
        <div className="mx-auto max-w-6xl px-5 py-20 md:py-28">
          <div className="mb-12 flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <h2 className="text-6xl md:text-8xl">Coachiv juhtimine – võtmeuskumused ja võtmetegevused</h2>
          </div>
          <div className="grid border-2 border-rule md:grid-cols-2">
            {[{ label: "USKUMUSED", items: beliefs, tone: "bg-bone" }, { label: "TEGEVUSED", items: actions, tone: "bg-background" }].map((g, gi) => (
              <div key={g.label} className={`${g.tone} ${gi === 0 ? "border-b-2 md:border-b-0 md:border-r-2" : ""} border-rule`}>
                <div className="flex items-center justify-between border-b-2 border-rule px-5 py-3">
                  <span className="eyebrow">{g.label}</span>
                  <span className="eyebrow text-muted-foreground">{gi === 0 ? "mida usud" : "mida teed"}</span>
                </div>
                {g.items.map((p, i) => (
                  <div key={p.name} className="group border-b-2 border-rule px-5 py-6 last:border-b-0 transition-colors hover:bg-signal-soft">
                    <div className="flex items-start gap-4">
                      <span className="display mt-1 text-xl text-muted-foreground">0{gi * 3 + i + 1}</span>
                      <div className="flex-1">
                        <h3 className="text-4xl md:text-5xl">{p.name}</h3>
                        <p className="mt-2 text-base">{p.meaning}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What you get */}
      <section className="grain border-b-2 border-rule bg-bone">
        <div className="mx-auto grid max-w-6xl gap-12 px-5 py-20 md:grid-cols-[1fr_1.2fr] md:py-28">
          <div>
            <p className="eyebrow mb-4">Mida saad</p>
            <h2 className="text-6xl md:text-7xl">Personaalne ja sisulise analüüsiga raport</h2>
            <p className="mt-6 max-w-md text-lg">
              Igaüks kuuest coachiva juhtimise parameetrist on eraldi oluline, rääkimata sellest, et tegevus ja uskumus võivad olla väga erinevad asjad - usume, aga ei tee. Raportis sisuline analüüs ja jutt sellest, mida tulemused mustrina sinu kui coachiva juhi tegemiste kohta räägivad. Ning veidi ka sellest, mida sellega ehk peale võiks hakata.
            </p>
            <p className="mt-4 text-sm text-muted-foreground">Ei tüüpe. Ei võrdlust teistega.</p>
          </div>
          <div className="border-2 border-rule bg-background p-6 shadow-[8px_8px_0_0_var(--rule)]">
            <p className="eyebrow border-b-2 border-rule pb-3">Tegevused</p>
            {sampleActions.map((r) => <ResultRow key={r.name} r={r} compact />)}
            <div className="mt-2 border-t-2 border-rule pt-5">
              <p className="eyebrow mb-3">Analüüs</p>
              <p className="border-l-4 border-signal pl-4 italic leading-relaxed">Sinu tugevus on selgus: inimesed tõenäoliselt teavad, mida sa neilt ootad ja sa tuled kokkulepete juurde tagasi. Samas jääb arengu võimaluse välja ütlemine sinu juhitöös pigem haruldaseks, kuigi su valikud uskumustes näitavad, et sinu usk inimeste arengusse on tugev.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How */}
      <section className="border-b-2 border-rule">
        <div className="mx-auto max-w-6xl px-5 py-20 md:py-28">
          <h2 className="mb-12 text-6xl md:text-7xl">Coachiv juht, mis sind ees ootab</h2>
          <ol className="grid gap-0 border-2 border-rule md:grid-cols-3">
            {[
              ["Täidad Coachiva juhi testi", "Võtab aega umbes viis minutit. Vastad selle järgi, mida päriselt teed ja usud."],
              ["Raport kohe kätte", "Saad kohe pärast täitmist oma tulemuste raporti ekraanile ja e-postile."],
              ["Kolm nädalat pehmet nügimist", "Saad soovi korral jätkata lihtsa programmiga, mis läbi igapäevase tähelepanu suunamise võtmetegevustele tugevdab hüppeliselt sinu võimekust coachiva juhina."],
            ].map(([t, d], i) => (
              <li key={t} className={`p-6 md:p-8 ${i < 2 ? "border-b-2 md:border-b-0 md:border-r-2" : ""} border-rule`}>
                <span className="display flex h-12 w-12 items-center justify-center border-2 border-rule bg-signal text-3xl">{i + 1}</span>
                <h3 className="mt-6 text-4xl">{t}</h3>
                <p className="mt-2 text-muted-foreground">{d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>


      {/* Programme */}
      <section className="border-b-2 border-rule bg-signal">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-[1.3fr_1fr] md:py-24">
          <div>
            <p className="eyebrow mb-4">Pärast testi</p>
            <h2 className="text-6xl md:text-8xl">{programme.title}</h2>
          </div>
          <div className="self-end">
            <p className="text-lg leading-relaxed">{programme.body}</p>
            <p className="display mt-6 text-4xl">{programme.price}</p>
            <p className="mt-2 text-sm">Valiku teed pärast raporti kätte saamist.</p>
          </div>
        </div>
      </section>

      {/* Close */}
      <section>
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-8 px-5 py-20 md:flex-row md:items-end md:justify-between md:py-28">
          <h2 className="text-6xl md:text-8xl">Kui coachiv sa<br />juhina oled?</h2>
          <div className="flex flex-col items-start gap-5">
            <StartButton big />
            <Link to="/alus" className="font-medium underline decoration-signal decoration-[3px] underline-offset-4">Vaata teadust testi taga →</Link>
          </div>
        </div>
      </section>
    </Page>
  );
}
