import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/site";

export const Route = createFileRoute("/privaatsus")({
  head: () => ({
    meta: [
      { title: "Privaatsus — Coachiva juhi test" },
      { name: "description", content: "Kuidas coachiva juhi test sinu andmeid kasutab ja hoiab." },
      { property: "og:title", content: "Privaatsus — Coachiva juhi test" },
      { property: "og:description", content: "Andmete kasutamine ja hoidmine." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Privacy,
});

const sections = [
  ["Mida kogume", "PLACEHOLDER — Sinu vastused 18 väitele ja e-posti aadress, kuhu raport saadetakse."],
  ["Milleks andmeid kasutame", "PLACEHOLDER — Raporti koostamiseks ja saatmiseks. Uudiskirja saadame ainult siis, kui oled selle valinud."],
  ["Kui kaua andmeid hoiame", "PLACEHOLDER — Täpsustamisel."],
  ["Sinu õigused", "PLACEHOLDER — Võid igal ajal küsida oma andmete väljavõtet või nende kustutamist."],
  ["Kontakt", "PLACEHOLDER — Raimo Ülavere · Radical Simplicity · radicalsimplicity.eu"],
];

function Privacy() {
  return (
    <Page>
      <article className="mx-auto max-w-2xl px-5 py-16 md:py-24">
        <h1 className="text-7xl md:text-8xl">Privaatsus</h1>
        <div className="prose-read mt-6">
          {sections.map(([h, t]) => (
            <section key={h}>
              <h2>{h}</h2>
              <p>{t}</p>
            </section>
          ))}
        </div>
      </article>
    </Page>
  );
}
