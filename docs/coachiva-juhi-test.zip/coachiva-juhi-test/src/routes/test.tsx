import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Header, Footer } from "@/components/site";
import { freqLabels, screen1, screen2 } from "@/lib/content";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/test")({
  head: () => ({
    meta: [
      { title: "Test — Coachiva juhi test" },
      { name: "description", content: "18 väidet coachiva juhi uskumuste ja tegevuste kohta. Umbes viis minutit." },
      { property: "og:title", content: "Tee coachiva juhi test" },
      { property: "og:description", content: "18 väidet, viis minutit, raport kohe." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TestPage,
});

type Step = "intro" | 1 | 2 | "email";

function Scale({
  value,
  onChange,
  labels,
  ends,
}: {
  value?: number | undefined;
  onChange: (v: number) => void;
  labels?: string[] | undefined;
  ends: [string, string];
}) {
  const caption = value && labels ? labels[value - 1] : null;
  return (
    <div>
      <div role="radiogroup" className="grid grid-cols-6 border-2 border-rule">
        {[1, 2, 3, 4, 5, 6].map((n) => {
          const on = value === n;
          return (
            <button
              key={n}
              role="radio"
              aria-checked={on}
              aria-label={labels ? `${n} ${labels[n - 1]}` : String(n)}
              onClick={() => onChange(n)}
              className={cn(
                "display h-14 border-r-2 border-rule text-3xl transition-colors last:border-r-0 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-signal md:h-16",
                on ? "bg-signal" : value ? "bg-background text-muted-foreground hover:bg-signal-soft" : "bg-background hover:bg-signal-soft",
              )}
            >
              {n}
            </button>
          );
        })}
      </div>
      <div className="mt-2 flex min-h-5 items-start justify-between gap-3 text-xs text-muted-foreground">
        {caption ? (
          <span className="w-full text-center text-sm font-semibold text-foreground">{caption}</span>
        ) : (
          <>
            <span>1 · {ends[0]}</span>
            <span className="text-right">{ends[1]} · 6</span>
          </>
        )}
      </div>
    </div>
  );
}

function TestPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("intro");
  const [a1, setA1] = useState<(number | undefined)[]>(Array(9).fill(undefined));
  const [a2, setA2] = useState<(number | undefined)[]>(Array(9).fill(undefined));
  const refs = useRef<(HTMLDivElement | null)[]>([]);

  const done = a1.filter(Boolean).length + a2.filter(Boolean).length;
  const screen = step === 1 ? screen1 : screen2;
  const answers = step === 1 ? a1 : a2;
  const setAnswers = step === 1 ? setA1 : setA2;

  const answer = (i: number, v: number) => {
    const first = answers[i] === undefined;
    setAnswers((prev) => prev.map((x, j) => (j === i ? v : x)));
    if (first) {
      setTimeout(() => refs.current[i + 1]?.scrollIntoView({ behavior: "smooth", block: "center" }), 180);
    }
  };

  const go = (s: Step) => {
    setStep(s);
    window.scrollTo({ top: 0 });
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header minimal />
      {step !== "intro" && (
        <div className="sticky top-0 z-10 border-b-2 border-rule bg-background">
          <div className="mx-auto flex max-w-2xl items-center gap-4 px-5 py-3">
            <span className="display w-16 text-2xl tabular-nums">{done} / 18</span>
            <div className="h-2 flex-1 bg-bone">
              <div className="h-full bg-signal transition-all duration-500" style={{ width: `${(done / 18) * 100}%` }} />
            </div>
          </div>
        </div>
      )}

      <main className="flex-1">
        {step === "intro" && (
          <section className="mx-auto max-w-2xl px-5 py-16 md:py-24 rise">
            <p className="eyebrow mb-6 text-muted-foreground">Enne alustamist</p>
            <h1 className="text-7xl md:text-8xl">18 väidet</h1>
            <p className="mt-8 text-xl leading-relaxed">
              Testis on 18 väidet kolme coachiva juhi võtmeuskumuse ja kolme võtmetegevuse kohta.
            </p>
            <p className="mt-4 border-l-4 border-signal pl-4 text-xl font-medium">Vasta selle järgi, mida sa päriselt usud ja teed.</p>
            <button onClick={() => go(1)} className="mt-10 border-2 border-rule bg-signal px-8 py-4 text-lg font-semibold shadow-[5px_5px_0_0_var(--rule)] transition-all hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[3px_3px_0_0_var(--rule)]">
              Alusta →
            </button>
          </section>
        )}

        {(step === 1 || step === 2) && (
          <section className="mx-auto max-w-2xl px-5 pb-20 pt-10">
            <p className="eyebrow text-muted-foreground">Osa {step} / 2</p>
            <h1 className="mt-3 text-4xl leading-[0.95] md:text-5xl">{screen.prompt}</h1>
            <div className="mt-8 space-y-4">
              {screen.items.map((s, i) => (
                <div
                  key={s}
                  ref={(el) => { refs.current[i] = el; }}
                  className={cn("border-2 border-rule p-4 transition-colors md:p-5", answers[i] ? "bg-bone" : "bg-background")}
                >
                  <p className="mb-4 flex gap-3 text-lg leading-snug">
                    <span className="display pt-0.5 text-xl text-muted-foreground">{(step === 1 ? 0 : 9) + i + 1}</span>
                    <span>{s}</span>
                  </p>
                  <Scale
                    value={answers[i]}
                    onChange={(v) => answer(i, v)}
                    labels={step === 1 ? freqLabels : undefined}
                    ends={step === 1 ? [freqLabels[0]!, freqLabels[5]!] : ["ei kirjelda üldse", "kirjeldab täpselt"]}
                  />
                </div>
              ))}
            </div>
            <div ref={(el) => { refs.current[9] = el; }} className="mt-10 flex items-center justify-between">
              {step === 2 ? <button onClick={() => go(1)} className="font-medium underline underline-offset-4">← Tagasi</button> : <span />}
              <button
                disabled={answers.some((x) => !x)}
                onClick={() => go(step === 1 ? 2 : "email")}
                className="border-2 border-rule bg-signal px-8 py-4 font-semibold transition-opacity disabled:cursor-not-allowed disabled:bg-bone disabled:text-muted-foreground"
              >
                Edasi →
              </button>
            </div>
          </section>
        )}

        {step === "email" && (
          <section className="mx-auto max-w-xl px-5 py-16 rise">
            <h1 className="text-6xl md:text-7xl">Kuhu raport saata?</h1>
            <form
              className="mt-10"
              onSubmit={(e) => {
                e.preventDefault();
                navigate({ to: "/raport" });
              }}
            >
              <label htmlFor="email" className="eyebrow">E-post</label>
              <input id="email" type="email" required autoComplete="email" className="mt-2 h-14 w-full border-2 border-rule bg-background px-4 text-lg outline-none focus:ring-4 focus:ring-signal" />
              <label className="mt-6 flex cursor-pointer gap-3">
                <input type="checkbox" className="mt-1 h-5 w-5 shrink-0 accent-[var(--ink)]" />
                <span>
                  <span className="font-medium">Tahan saada ka Raimo uudiskirja</span>
                  <span className="mt-1 block text-sm text-muted-foreground">Ainult sisu, mida saad juhina kasutada. Loobuda saad ühe klõpsuga.</span>
                </span>
              </label>
              <button type="submit" className="mt-8 w-full border-2 border-rule bg-signal py-4 text-lg font-semibold shadow-[5px_5px_0_0_var(--rule)]">
                Näita raportit
              </button>
              <p className="mt-4 text-sm text-muted-foreground">
                Raport saadetakse sellele aadressile. Loe lähemalt: <Link to="/privaatsus" className="text-foreground underline underline-offset-4">Privaatsus</Link>
              </p>
            </form>
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}
