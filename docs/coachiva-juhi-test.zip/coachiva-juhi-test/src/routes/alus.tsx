import { createFileRoute, Link } from "@tanstack/react-router";
import { Page } from "@/components/site";
import { parts } from "@/lib/content";

export const Route = createFileRoute("/alus")({
  head: () => ({
    meta: [
      { title: "Millele test tugineb — Coachiva juhi test" },
      { name: "description", content: "Kuus osa ja nende teaduslikud allikad. Mida test ei mõõda." },
      { property: "og:title", content: "Millele test tugineb — Coachiva juhi test" },
      { property: "og:description", content: "Allikad ja testi piirid." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Alus,
});

function Alus() {
  return (
    <Page>
      <article className="mx-auto max-w-2xl px-5 py-16 md:py-24">
        <p className="eyebrow mb-6 text-muted-foreground">Taust</p>
        <h1 className="text-7xl md:text-8xl">Millele test tugineb</h1>
        <div className="prose-read mt-10">
          <h2>Miks see test on olemas</h2>
          <p>PLACEHOLDER — Coachivast juhtimisest räägitakse palju, kuid harva öeldakse, millest see täpselt koosneb. See test jagab selle kuueks osaks, mida saab eraldi vaadata.</p>
          <p>PLACEHOLDER — Iga osa põhineb uurimustel.</p>
        </div>
      </article>

      <section className="border-y-2 border-rule">
        <div className="mx-auto max-w-5xl px-5 py-12">
          <div className="hidden grid-cols-[1fr_1.6fr_1.6fr_1fr] gap-6 border-b-4 border-rule pb-3 md:grid">
            {["Osa", "Mida see tähendab", "Peamised allikad"].map((h) => <span key={h} className="eyebrow">{h}</span>)}
          </div>
          {parts.map((p) => (
            <div key={p.name} className="grid gap-2 border-b-2 border-rule py-6 last:border-b-0 md:grid-cols-[1fr_1.6fr_1.6fr] md:gap-6">
              <div>
                <span className="eyebrow text-muted-foreground">{p.group}</span>
                <h3 className="text-4xl">{p.name}</h3>
              </div>
              <p><span className="eyebrow mb-1 block text-muted-foreground md:hidden">Mida see tähendab</span>{p.meaning}</p>
              <p className="text-sm text-muted-foreground"><span className="eyebrow mb-1 block md:hidden">Peamised allikad</span>{p.sources}</p>
            </div>
          ))}
          <p className="mt-6 text-xs text-muted-foreground">PLACEHOLDER — allikad on näidisena, asenda lõplikega.</p>
        </div>
      </section>

      <article className="mx-auto max-w-2xl px-5 py-16">
        <div className="prose-read">
          <h2>Mida test ei mõõda</h2>
          <ul>
            <li>Seda, kui hästi sa tegevusi teed. Seda näevad kõige paremini sinu inimesed.</li>
            <li>Sinu isiksust ega juhitüüpi.</li>
            <li>Sinu asukohta teiste juhtide suhtes.</li>
          </ul>
          <h2>Raimo Ülavere</h2>
          <p>PLACEHOLDER — Raimo Ülavere on juhtide coach ja Radical Simplicity asutaja. Lühike tutvustus tema taustast ja tööst juhtidega.</p>
          <p><Link to="/test">Alusta testi →</Link></p>
        </div>
      </article>
    </Page>
  );
}
