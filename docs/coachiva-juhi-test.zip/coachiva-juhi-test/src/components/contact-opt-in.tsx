import { useId } from "react";
import { Checkbox } from "@/components/ui/checkbox";

export function ContactOptIn() {
  const id = useId();

  return (
    <div className="mt-8 flex items-start gap-3 border-t-2 border-rule pt-6">
      <Checkbox id={id} name="contactRequested" className="mt-1 h-5 w-5 border-2 border-rule bg-background" />
      <label htmlFor={id} className="cursor-pointer text-base leading-relaxed">
        Tahan, et Raimo võtaks minuga ühendust (koolitus/coaching vms teema)
      </label>
    </div>
  );
}