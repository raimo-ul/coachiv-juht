import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { strengthLevel, type Strength } from "@/lib/content";
import { cn } from "@/lib/utils";

export function Header({ minimal = false }: { minimal?: boolean | undefined }) {
  return (
    <header className="border-b-2 border-rule bg-background">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-5">
        <Link to="/" className="flex items-center gap-2">
          <span className="block h-4 w-4 bg-signal ring-2 ring-rule" />
          <span className="display text-2xl leading-none pt-1">Coachiva juhi test</span>
        </Link>
        {!minimal && (
          <Link to="/test" className="eyebrow border-2 border-rule bg-signal px-3 py-2 transition-transform hover:-translate-y-0.5">
            Alusta testi
          </Link>
        )}
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-auto border-t-2 border-rule bg-bone">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-10 text-sm md:flex-row md:items-end md:justify-between">
        <div className="flex gap-3">
          <Link to="/alus" className="underline decoration-2 underline-offset-4 hover:decoration-signal">Mille peale test tugineb</Link>
          <span aria-hidden>·</span>
          <Link to="/privaatsus" className="underline decoration-2 underline-offset-4 hover:decoration-signal">Privaatsus</Link>
        </div>
        <p className="text-muted-foreground">
          Raimo Ülavere · Radical Simplicity ·{" "}
          <a href="https://radicalsimplicity.eu" className="text-foreground underline decoration-2 underline-offset-4">radicalsimplicity.eu</a>
        </p>
      </div>
    </footer>
  );
}

export function Page({ children, minimal }: { children: ReactNode; minimal?: boolean | undefined }) {
  return (
    <div className="flex min-h-screen flex-col">
      <Header minimal={minimal} />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

export function StrengthTag({ strength, className }: { strength: Strength; className?: string }) {
  const lvl = strengthLevel[strength];
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <span className="flex gap-0.5" aria-hidden>
        {[1, 2, 3, 4].map((i) => (
          <span key={i} className={cn("h-3 w-1.5 border border-rule", i <= lvl ? "bg-ink" : "bg-transparent")} />
        ))}
      </span>
      <span className="eyebrow">{strength}</span>
    </span>
  );
}

/** Six-step frequency track; shows position rather than a grade. */
export function Track({ value, animate = true }: { value: number; animate?: boolean }) {
  const pct = ((value - 1) / 5) * 100;
  return (
    <div className="relative h-8" aria-hidden>
      <div className="absolute inset-x-0 top-1/2 h-0.5 -translate-y-1/2 bg-bone-deep" />
      <div className={cn("absolute left-0 top-1/2 h-2 -translate-y-1/2 bg-signal", animate && "grow")} style={{ width: `${pct}%` }} />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <span key={i} className="absolute top-1/2 h-3 w-0.5 -translate-y-1/2 bg-rule" style={{ left: `calc(${i * 20}% - 1px)` }} />
      ))}
      <span className="absolute top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-rule bg-background" style={{ left: `${pct}%` }} />
    </div>
  );
}
