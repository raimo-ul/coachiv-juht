import { fmt } from "@/lib/content";
import { Track } from "./site";

export type Result = { name: string; score: number; meaning: string; landed: string };

export const sampleActions: Result[] = [
  {
    name: "Juhendamine",
    score: 4.7,
    meaning: "Inimene teab, millist tulemust temalt oodatakse, saab tagasisidet oma tegevuse kohta ja juht tuleb kokkulepete juurde tagasi.",
    landed: "Ootused, tagasiside ja kokkulepete juurde tagasi tulemine on sinu nädalas tavaline osa.",
  },
  {
    name: "Võimestamine",
    score: 3.3,
    meaning: "Juht küsib ja kuulab ning jätab otsuse inimesele, kelle töö see on.",
    landed: "Teadlikult küsid ja kuulad paar korda nädalas; inimese enda kätte jääb otsuse tegemine pigem harvem.",
  },
  {
    name: "Inspireerimine",
    score: 2.4,
    meaning: "Juht ütleb välja, milles inimene on arenenud, ja annab talle väljakutseid, mis viivad edasi.",
    landed: "Arengu võimaluse ja potentsiaali välja ütlemine ja väljakutse esitamine jõudsid sinu päevadesse viimase kuu jooksul vaid üksikutel kordadel.",
  },
];

export const sampleBeliefs: Result[] = [
  {
    name: "Inimene",
    score: 5.2,
    meaning: "Inimesed saavad areneda — ka need, kes praegu ülesandega toime ei tule.",
    landed: "Sinu valikud näitavad selget usku, et inimene saab õppida.",
  },
  {
    name: "Suhe",
    score: 4.1,
    meaning: "Töötaja usaldus juhi vastu on coachiva juhtimise eeldus.",
    landed: "Hoiad usaldust enamasti teadlikult; ebamugavates olukordades vähem.",
  },
  {
    name: "Autonoomia",
    score: 3.0,
    meaning: "Inimene suudab end ise juhtida, kui otsus on tema oma.",
    landed: "Sinu valikutes on kontroll ja vabadus tasakaalus, kaal kaldub kontrolli poole.",
  },
];

export function ResultRow({ r, compact = false }: { r: Result; compact?: boolean }) {
  return (
    <div className="border-t-2 border-rule py-6 first:border-t-0">
      <div className="flex items-baseline justify-between gap-4">
        <h3 className="text-3xl md:text-4xl">{r.name}</h3>
        <span className="display text-4xl tabular-nums md:text-5xl">{fmt(r.score)}</span>
      </div>
      <div className="mt-3">
        <Track value={r.score} />
        <div className="mt-1 flex justify-between text-[0.68rem] text-muted-foreground">
          <span>harva</span>
          <span>sageli</span>
        </div>
      </div>
      {!compact && <p className="mt-4 text-sm text-muted-foreground">{r.meaning}</p>}
      <p className="mt-2 font-medium">{r.landed}</p>
    </div>
  );
}
